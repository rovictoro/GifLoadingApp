# Android-GifLoadingExample
Simple example app for loading and displaying GIFs.

1. Experimented with the [Giphy SDK](https://github.com/Giphy/giphy-android-sdk-core) and displayed GIFs using [Glide](https://github.com/bumptech/glide).





