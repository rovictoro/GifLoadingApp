package com.rovictoro.giphy.utils;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Handler;
import android.os.Looper;
import android.support.annotation.Nullable;
import android.util.Log;
import android.util.LruCache;
import android.view.inputmethod.InputMethodManager;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.GlideBuilder;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.load.engine.bitmap_recycle.LruBitmapPool;
import com.bumptech.glide.load.engine.cache.InternalCacheDiskCacheFactory;
import com.bumptech.glide.load.engine.cache.LruResourceCache;
import com.bumptech.glide.load.resource.gif.GifDrawable;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.RequestOptions;

//import com.bumptech.glide.request.target.SimpleTarget;
import com.bumptech.glide.request.target.SimpleTarget;
import com.bumptech.glide.request.target.Target;
import com.bumptech.glide.request.transition.Transition;
import com.giphy.sdk.core.models.Media;
import com.giphy.sdk.core.models.enums.MediaType;
import com.giphy.sdk.core.network.api.CompletionHandler;
import com.giphy.sdk.core.network.api.GPHApi;
import com.giphy.sdk.core.network.api.GPHApiClient;
import com.giphy.sdk.core.network.response.ListMediaResponse;
import com.rovictoro.giphy.gifsearch.GifAdapter;
import com.rovictoro.giphy.models.GifModel;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;

import io.reactivex.BackpressureStrategy;
import io.reactivex.Observable;
import io.reactivex.Observer;
import io.reactivex.Single;
import io.reactivex.SingleObserver;
import io.reactivex.disposables.Disposable;

import static android.content.Context.ACTIVITY_SERVICE;
import static android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN;

public interface Utils {

    //private Utils() {}

    public static void hideSoftKeyboard(final Activity activityIn) {
        final WeakReference<Activity> mReference =  new WeakReference<Activity>(activityIn);
        final Activity activity = mReference.get();
        Handler mHandler = new Handler(Looper.getMainLooper());
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (activity != null) {
                    InputMethodManager inputMethodManager = (InputMethodManager) activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
                    if (inputMethodManager != null && activity.getCurrentFocus() != null) {
                        inputMethodManager.hideSoftInputFromWindow(activity.getCurrentFocus().getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);//0  InputMethodManager.RESULT_HIDDEN
                    }
                    activity.getWindow().setSoftInputMode(SOFT_INPUT_ADJUST_PAN); //SOFT_INPUT_ADJUST_PAN  SOFT_INPUT_ADJUST_RESIZE
                }
            }},100);
    }


    public static SingleObserver<List<GifModel>> getSingleObserver(final GifAdapter gifAdapterIn) {

        final WeakReference<GifAdapter> mReferenceAdapter =  new WeakReference<GifAdapter>(gifAdapterIn);
        final GifAdapter gifAdapter = mReferenceAdapter.get();

        return new SingleObserver<List<GifModel>>() {
            @Override
            public void onSubscribe(Disposable d) {
                Log.d("SingleObserver", " onSubscribe : " + d.isDisposed());
            }

            @Override
            public void onSuccess(List<GifModel> value) {

                gifAdapter.addGifs(value);
                Log.e("SingleObserver", " onNext value : " + value.size());
            }


            @Override
            public void onError(Throwable e) {

                Log.d("SingleObserver", " onError : " + e.getMessage());
            }
        };
    }

    public static Observer<List<GifModel>> getObserver(final GifAdapter gifAdapterIn) {

        final WeakReference<GifAdapter> mReferenceAdapter =  new WeakReference<GifAdapter>(gifAdapterIn);
        final GifAdapter gifAdapter = mReferenceAdapter.get();

        return new Observer<List<GifModel>>() {
            @Override
            public void onSubscribe(Disposable d) {
                Log.d("Observer", " onSubscribe : " + d.isDisposed());
            }

            @Override
            public void onNext(List<GifModel> value) {
                Log.d("Observer", " onNext : " + value.size());
            }

            @Override
            public void onComplete() {

                Log.e("Observer", " onComplete : " );
            }

            @Override
            public void onError(Throwable e) {

                Log.d("Observer", " onError : " + e.getMessage());
            }
        };
    }

    public static SingleObserver<GifModel> getSingleObserverGif(final GifAdapter gifAdapterIn) {

        final WeakReference<GifAdapter> mReferenceAdapter =  new WeakReference<GifAdapter>(gifAdapterIn);
        final GifAdapter gifAdapter = mReferenceAdapter.get();

        return new SingleObserver<GifModel>() {
            @Override
            public void onSubscribe(Disposable d) {

                d.dispose();
                Log.d("SingleObserver", " onSubscribe : " + d.isDisposed());
            }

            @Override
            public void onSuccess(GifModel value) {

                gifAdapter.addGif(value);
                //gifAdapter.updateGifs();
                Log.e("SingleObserver", " onNext value : " + value.getTitle());
            }


            @Override
            public void onError(Throwable e) {

                Log.d("SingleObserver", " onError : " + e.getMessage());
            }
        };
    }

    public static SingleObserver<GifModel> getSingleObserverUpdateGif(final GifAdapter gifAdapterIn) {

        final WeakReference<GifAdapter> mReferenceAdapter =  new WeakReference<GifAdapter>(gifAdapterIn);
        final GifAdapter gifAdapter = mReferenceAdapter.get();

        return new SingleObserver<GifModel>() {
            @Override
            public void onSubscribe(Disposable d) {

                d.dispose();
                Log.d("SingleObserver", " onSubscribe : " + d.isDisposed());
            }

            @Override
            public void onSuccess(GifModel value) {

                //gifAdapter.addGif(value);
                gifAdapter.updateGif(value);
                Log.e("SingleObserver", " onNext value : " + value.getTitle());
            }


            @Override
            public void onError(Throwable e) {

                Log.d("SingleObserver", " onError : " + e.getMessage());
            }
        };
    }

    public static void searchGPHApi(final Activity activityIn, String searchWord, final GifAdapter gifAdapterIn) {
        final WeakReference<Activity> mReference =  new WeakReference<Activity>(activityIn);
        final Activity activity = mReference.get();

        final WeakReference<GifAdapter> mReferenceAdapter =  new WeakReference<GifAdapter>(gifAdapterIn);
        final GifAdapter gifAdapter = mReferenceAdapter.get();

        final String GPH_API_KEY = "DzbDBcffvbP0W2C2XAshCmIxsKVnj7mu";
        final List<GifModel> searchResultGifModel = new ArrayList<GifModel>();


        if (isNetworkAvailable(activity)){

            GPHApi client;client = new GPHApiClient(GPH_API_KEY);
            client.search(searchWord, MediaType.gif, null, null, null, null, new CompletionHandler<ListMediaResponse>() {
                @Override
                public void onComplete(ListMediaResponse result, Throwable e) {
                    if (result == null) {
                        // Do what you want to do with the error
                    } else {
                        if (result.getData() != null) {

                            for (Media gif : result.getData()) {
                                //gif.getImages().getOriginal().getGifSize();
                                GifModel mNewGifModel = new GifModel();
                                mNewGifModel.setGifUrl(gif.getImages().getOriginal().getGifUrl());
                                mNewGifModel.setTitle(gif.getTitle());
                                searchResultGifModel.add(mNewGifModel);
                                //loadGifToCashGlide(activity, mNewGifModel, gifAdapter);
                                Log.e("searchGPHApi", " " + gif.getImages().getOriginal().getGifUrl());
                            }
                            Single.just(searchResultGifModel)
                                    .subscribe(getSingleObserver(gifAdapter));
                            searchResultGifModel.clear();

                        } else {
                            Log.e("searchGPHApi", "No results found");
                        }
                    }
                }
            });
        }

    }

  /*  public Completable getMyCompletable() {
        return getFirstCompletable().andThen(getSecondCompletable());
    }

    public Completable getFirstCompletable() {
        return Completable.fromFuture(getFirstFuture());
    }


    public Completable getSecondCompletable() {
        return Completable.defer(() -> Completable.fromFuture(getSecondFuture()));
    }
    */

    public static void searchQueueGPHApi(final Activity activityIn, String searchWord, final GifAdapter gifAdapterIn) {
        final WeakReference<Activity> mReference =  new WeakReference<Activity>(activityIn);
        final Activity activity = mReference.get();

        final WeakReference<GifAdapter> mReferenceAdapter =  new WeakReference<GifAdapter>(gifAdapterIn);
        final GifAdapter gifAdapter = mReferenceAdapter.get();

        final String GPH_API_KEY = "DzbDBcffvbP0W2C2XAshCmIxsKVnj7mu";
        final List<GifModel> searchResultGifModel = new ArrayList<GifModel>();


        if (isNetworkAvailable(activity)){

            GPHApi client = new GPHApiClient(GPH_API_KEY);
            client.search(searchWord, MediaType.gif, null, null, null, null, new CompletionHandler<ListMediaResponse>(){
                @Override
                public void onComplete(ListMediaResponse result, Throwable e) {
                    if (result == null) {
                        // Do what you want to do with the error
                    } else {
                        if (result.getData() != null) {

                            int position = 0;
                            for (Media gif : result.getData()) {
                                //gif.getImages().getOriginal().getGifSize();

                                GifModel mNewGifModel = new GifModel();
                                mNewGifModel.setGifUrl(gif.getImages().getOriginal().getGifUrl());
                                mNewGifModel.setFixedWidthDownsampledUrl(gif.getImages().getFixedWidthDownsampled()/*.getDownsized()*/.getGifUrl());
                                mNewGifModel.setTitle(gif.getTitle());
                                mNewGifModel.setSize(gif.getImages().getOriginal().getGifSize());
                                mNewGifModel.setFixedWidthDownsampledSize(gif.getImages().getFixedWidthDownsampled().getGifSize());
                                mNewGifModel.setPosition(position);
                                //GlideApp.with(activity).download(gif.getImages().getOriginal().getGifUrl());
                                searchResultGifModel.add(mNewGifModel);
                                position++;
                                //loadGifToCashGlide(activity, mNewGifModel, gifAdapter);

                                Log.e("searchGPHApi", " " + gif.getImages().getOriginal().getGifUrl()
                                        + " size: "+ gif.getImages().getOriginal().getGifSize()
                                        + " downsized: " + gif.getImages().getFixedWidthDownsampled().getGifUrl() + " FixedWidthDownsampledSize: " + gif.getImages().getFixedWidthDownsampled().getGifSize());
                            }

                            Single.just(searchResultGifModel)
                                    .subscribe(getSingleObserver(gifAdapter));

                            //final TestScheduler scheduler = new TestScheduler();
                            //scheduler.advanceTimeBy(10, TimeUnit.MINUTES);

                            Observable.fromIterable(searchResultGifModel)
                                    //.subscribeOn(Schedulers.io())
                                    //.observeOn(AndroidSchedulers.mainThread())

                                    //.doOnNext(gif -> Log.e("doOnNext gif: ", "gif: " + gif.getTitle()))
                                    //.delaySubscription(gif -> gif.onComplete())
                                    //.delaySubscription()
                                    //.buffer(1)
                         /*           .delay(giff -> Observable.fromCallable(() -> {  // concat
                                        Log.e("fromCallable", "gif: " + giff.getTitle());
                                        loadGifToCashGlide(activity, giff, gifAdapter);
                                        return result;
                                    }))
                        */  .buffer(4)
                                    .flatMap(giff -> Observable.fromIterable(giff)
                                            .doOnNext(/*.fromCallable(*/(gifff) -> {  /* concat */
                                                Log.e("fromCallable", "gif: " + gifff.getTitle());
                                                loadGifToCashGlide(activity, gifff, gifAdapter);

                                            /*    GlideApp.with(activity)
                                                        .asGif()
                                                        .load(gif.getFixedWidthDownsampledUrl())
                                                        .getDownloadOnlyRequest()
                                                        .addListener(new RequestListener<File>() {
                                                    @Override
                                                    public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<File> target, boolean isFirstResource) {
                                                        Log.e("fromCallable gif: ", "gif: " + "false");
                                                        return false;
                                                    }

                                                    @Override
                                                    public boolean onResourceReady(File resource, Object model, Target<File> target, DataSource dataSource, boolean isFirstResource) {
                                                        gifAdapter.addGif(gif);
                                                        Log.e("fromCallable gif: ", "gif: " + gif.getTitle());
                                                        return true;
                                                    }
                                                });*/

                                                //do something, get your Data object
                                                //return result;
                                            }) )
                                    .toFlowable(BackpressureStrategy.BUFFER)
                                    .toList()
                                    .doOnSuccess(i -> Log.e("doOnSuccess","Received: " + i))
                                    .doOnError(er -> Log.e("doOnError","Error Captured: " + er))
                                    .subscribe();

                        /*    Observable.fromIterable(searchResultGifModel)
                                    //.subscribeOn(Schedulers.io())
                                    //.observeOn(AndroidSchedulers.mainThread())
                                    .flatMap(gifModel ->{
                                        if(gifModel != null){
                                            return Observable.fromCallable(() -> {
                                                gifAdapter.addGif(gifModel);
                                                Log.e("flatMap: ", "gif: " + gifModel.getTitle());
                                                //do something, get your Data object
                                                return result;
                                            });

                                         }else{
                                            return Observable.error(NullPointerException::new);

                                        }
                                    })
                                    .retryWhen(observable -> observable.flatMap(throwable->{
                                        Log.e("flatMap: ", "gif: " + "error" );
                                               // other error, pass it further
                                            return Observable.error(throwable);
                                    }))
                                    //.doOnNext()
                                    .subscribe(getObserver(gifAdapter));
            */

                        /*    Single.just(searchResultGifModel)
                                    //.doOnSuccess()
                                    //.doOnError()
                                    //.doOnEvent()
                                    .subscribe(getSingleObserver(gifAdapter));
                                    */

                            searchResultGifModel.clear();
                        } else {
                            Log.e("searchGPHApi", "No results found");
                        }
                    }
                }
            });
        }
    }


    public static void loadGifToCashGlide(final Activity activityIn, final GifModel gifModel, final GifAdapter gifAdapterIn) {
        final WeakReference<Activity> mReference =  new WeakReference<Activity>(activityIn);
        final Activity activity = mReference.get();

        final WeakReference<GifAdapter> mReferenceGifAdapter =  new WeakReference<GifAdapter>(gifAdapterIn);
        final GifAdapter gifAdapter = mReferenceGifAdapter.get();

        final LruCache<String, GifDrawable> memCache = new LruCache<String, GifDrawable>(300) {
            @Override
            protected int sizeOf(String key, GifDrawable image) {
                return image.getSize();//.getByteCount()/1024;
            }
        };

         /*GlideRequest<GifDrawable>  gr = */Glide/*App*/.with(activity)
                .asGif()
                .centerInside()
                .load(gifModel.getFixedWidthDownsampledUrl()/*getGifUrl()*/)
                .fitCenter()
        //        .thumbnail(1.0f)
                .apply(RequestOptions.diskCacheStrategyOf(DiskCacheStrategy.DATA/*.NONE*//*RESOURCE*//*.AUTOMATIC*/))
                .addListener(new RequestListener<GifDrawable>() {
                    @Override
                    public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<GifDrawable> target, boolean isFirstResource) {
                        //Log.e("onLoadFailed: ", "gif: " + "title: " + gifModel.getTitle() + " size: " + gifModel.getFixedWidthDownsampledSize() /*resource.getSize()*/);
                        loadGifToCashGlide(activity, gifModel,gifAdapter);
                        return false;
                    }

                    @Override
                    public boolean onResourceReady(GifDrawable resource, Object model, Target<GifDrawable> target, DataSource dataSource, boolean isFirstResource) {
                        Log.e("onResourceReady: ", "gif: " + "title: " + gifModel.getTitle() + " size: " + gifModel.getFixedWidthDownsampledSize() + " original size: " + gifModel.getSize() /*resource.getSize()*/);
                        //memCache.put(gifModel.getFixedWidthDownsampledUrl()/*.getGifUrl()*/, resource);
                        Single.just(gifModel)
                                .subscribe(getSingleObserverUpdateGif(gifAdapter));
                        return true;
                    }
                })

                //.getDownloadOnlyRequest();//.download(gifModel.getGifUrl());

                .into(new SimpleTarget<GifDrawable>() {
                    @Override
                    public void onResourceReady(GifDrawable resource, Transition<? super GifDrawable> transition) {
                        memCache.put(gifModel.getFixedWidthDownsampledUrl(), resource); //.getGifUrl()
                        //gifAdapter.addGif(gifModel);
                        Log.e("loadGifToCashGlide: ", "gif: " + "title: " + gifModel.getTitle() + " size: " + gifModel.getFixedWidthDownsampledSize() ); //resource.getSize()

                        //Single.just(gifModel)
                        //        .subscribe(getSingleObserverGif(gifAdapter));
                    }
                });
    }

    public static void loadGifGlide(final Activity activityIn, final GifModel gifModel, final ImageView viewIn){
        final WeakReference<Activity> mReference =  new WeakReference<Activity>(activityIn);
        final Activity activity = mReference.get();

        final WeakReference<ImageView> mReferenceView =  new WeakReference<ImageView>(viewIn);
        final ImageView view = mReferenceView.get();

        Glide/*App*/.with(activity)
                .asGif()
                //.centerInside()
                .load(gifModel.getFixedWidthDownsampledUrl()/*.getGifUrl()*/)
                .fitCenter()
              //  .thumbnail(1.0f)

                .addListener(new RequestListener<GifDrawable>() {
                    @Override
                    public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<GifDrawable> target, boolean isFirstResource) {
                        Log.e("onLoadFailed: ", "gif: " + "title: " + gifModel.getTitle() + " size: " + gifModel.getFixedWidthDownsampledSize() );
                        //loadGifGlide(activity, gifModel,view);
                        return false;
                    }

                    @Override
                    public boolean onResourceReady(GifDrawable resource, Object model, Target<GifDrawable> target, DataSource dataSource, boolean isFirstResource) {

                        return false;
                    }
                })
                .apply(RequestOptions.diskCacheStrategyOf(DiskCacheStrategy.DATA/*.NONE*//*RESOURCE*//*.AUTOMATIC*/))
                .onlyRetrieveFromCache(true)
                .into(view);
    }

    public static void buildGlide(final Activity activityIn, int cacheSize){  //cash size in %
        final WeakReference<Activity> mReference =  new WeakReference<Activity>(activityIn);
        final Activity activity = mReference.get();
        GlideBuilder gb = new GlideBuilder();

        //set mem cache size to 8% of available memory
        LruResourceCache lruMemCache = new LruResourceCache(getMemCacheSize(activity,cacheSize));
        gb.setMemoryCache(lruMemCache);

        //set disk cache 300 mb
        InternalCacheDiskCacheFactory diskCacheFactory =
                new InternalCacheDiskCacheFactory(activity, 300);
        gb.setDiskCache(diskCacheFactory);

        //set BitmapPool with 1/10th of memory cache's size
        LruBitmapPool bitmapPool = new LruBitmapPool(getMemCacheSize(activity,cacheSize)/10);
        gb.setBitmapPool(bitmapPool);

        //set custom Glide as global singleton
        Glide.init(activity, gb);
    }
    public static int getMemCacheSize(final Activity activityIn, int percent){
        final WeakReference<Activity> mReference =  new WeakReference<Activity>(activityIn);
        final Activity activity = mReference.get();
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        ((ActivityManager)
                activity.getSystemService(ACTIVITY_SERVICE)).getMemoryInfo(mi);

        double availableMemory= mi.availMem;
        return (int)(percent*availableMemory/100);
    }

    public static boolean isNetworkAvailable(final Activity activityIn) {
        final WeakReference<Activity> mReference =  new WeakReference<Activity>(activityIn);
        final Activity activity = mReference.get();
        ConnectivityManager manager = (ConnectivityManager) activity.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = manager.getActiveNetworkInfo();
        boolean isAvailable = false;
        if (networkInfo != null && networkInfo.isConnected()) {
            isAvailable = true;
        }
        return isAvailable;
    }

}
